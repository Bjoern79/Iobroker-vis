const CACHE = 'dashboard-shell-v1';
const SHELL = [
  './',
  './index.html',
  './css/app.css',
  './js/app.js',
  './manifest.json',
  './icons/icon-180.png',
  './icons/icon-192.png',
  './icons/icon-512.png',
];

self.addEventListener('install', (e)=>{
  e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)));
  self.skipWaiting();
});

self.addEventListener('activate', (e)=>{
  e.waitUntil(
    caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))
  );
  self.clients.claim();
});

// Only cache-first the app shell itself (same-origin, our own files).
// Everything else (in particular the simple-api data calls on a different
// host/port) always goes straight to the network, never cached.
self.addEventListener('fetch', (e)=>{
  const url = new URL(e.request.url);
  if (url.origin !== self.location.origin) return; // let cross-origin (simple-api) pass through untouched
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request))
  );
});
